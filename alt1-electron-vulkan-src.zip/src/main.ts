import { app, BrowserWindow, dialog, globalShortcut, ipcMain, WebContents } from "electron";
import * as electron from "electron";
import * as path from "path";
import { Menu, Tray } from "electron/main";
import { MenuItemConstructorOptions, nativeImage } from "electron/common";
import { handleSchemeArgs } from "./schemehandler";
import { patchImageDataShow, relPath, schemestring } from "./lib";
import { getActiveWindow, OSWindow, OSWindowPin, reloadAddon, shutdownAddon } from "./native";
import { detectInstances, getRsInstanceFromWnd, RsInstance, rsInstances, initRsInstanceTracking, stopRsInstanceTracking } from "./rsinstance";
import { AppPermission, Bookmark, settings } from "./settings";
import { boundMethod } from "autobind-decorator";
import * as remoteMain from "@electron/remote/main";
import { initIpcApi } from "./ipcapi";
import * as fs from "fs";
import { execSync } from 'child_process';
import { type AppUpdater } from 'electron-updater';

if (process.env.NODE_ENV === "development") {
	patchImageDataShow();
	//exposed on global for debugging purposes
	(global as any).native = require("./native");
}
(global as any).Alt1lite = require("./main");

export const admins = new Set<number>();
export const managedWindows: ManagedWindow[] = [];
export function getManagedWindow(w: WebContents) { return managedWindows.find(q => q.window.webContents == w); }
export function getManagedAppWindow(id: number) { return managedWindows.find(q => q.appFrameId == id || q.window.webContents.id == id); }
var tray: Tray | null = null;
var alt1icon = nativeImage.createFromPath(relPath(require("!file-loader!./imgs/alt1icon.png").default));
var tooltipWindow: TooltipWindow | null = null;
var alwaysOpenDevtools = false;

app.on("browser-window-created", (e, wnd) => {
	if (alwaysOpenDevtools) {
		wnd.webContents.openDevTools({ mode: "undocked" });
	}
});

const originalCwd = process.cwd();

if (!app.requestSingleInstanceLock()) { app.exit(); }

settings.loadOrFetch();
settings.on("changed", () => {
	for (let admin of selectAdminContexts()) {
		admin.send("settings-changed");
	}
	updateTray();
});
remoteMain.initialize();

app.on("before-quit", e => {
	shutdownAddon();
	rsInstances.forEach(c => c.close());
	stopRsInstanceTracking();
	settings.save();
});
app.on("second-instance", (e, argv, cwd) => handleSchemeArgs(argv));
app.on("window-all-closed", () => {
	// existance of this listener prevent electron default behavior of closing
});

app.once("ready", async () => {
	if (settings.checkForUpdates.checkOnStartup) {
		checkForUpdate();
	}
	if (process.platform === 'linux') {
		registerProtocolHandlerLinux();
	} else {
		registerProtocolHandler();
	}
	handleSchemeArgs(process.argv);
	if (!globalShortcut.register("Alt+1", alt1Pressed)) {
		console.log("failed to register alt+1 hotkey");
	}
	if (!app.accessibilitySupportEnabled) {
		app.setAccessibilitySupportEnabled(true);
	}
	if(app.dock) {
		app.dock.hide();
	}
	if (process.platform === "darwin") {
		if (!app.accessibilitySupportEnabled) {
			app.setAccessibilitySupportEnabled(true);
		}
		if (app.dock) {
			app.dock.hide();
		}
	}

	globalShortcut.register("Alt+1", alt1Pressed);
	drawTray();
	initIpcApi(ipcMain);
	initRsInstanceTracking();
});

function registerProtocolHandler() {
	if (process.defaultApp) {
		if (process.argv.length >= 2) {
			app.setAsDefaultProtocolClient(schemestring, process.execPath, [path.resolve(process.argv[1])]);
		}
	} else {
		app.setAsDefaultProtocolClient(schemestring);
	}
}

function registerProtocolHandlerLinux() {
	const appDir = process.env.APPDIR;
	const execPath = process.env.APPIMAGE ?? process.execPath;
	if (!appDir || !process.env.APPIMAGE) return;
	console.log("execpath: ", execPath);

	const appName = app.getName().toLowerCase();
	const desktopDir = path.join(process.env.HOME!, '.local/share/applications');
	const destPath = path.join(desktopDir, `${appName}.desktop`);

	const srcPath = path.join(appDir, `${appName}.desktop`);
	let contents = fs.readFileSync(srcPath, 'utf8');

	contents = contents.replace(/^Exec=.*/m, `Exec=${execPath} %U`);

	const existing = fs.existsSync(destPath) ? fs.readFileSync(destPath, 'utf8') : '';
	if (existing === contents) return;

	fs.mkdirSync(desktopDir, { recursive: true });
	fs.writeFileSync(destPath, contents);
	execSync(`xdg-mime default ${appName}.desktop x-scheme-handler/alt1`);
	execSync(`update-desktop-database ${desktopDir}`);
	console.log('Protocol handler registered');
}

export async function checkForUpdate() {
	const autoUpdater = getAutoUpdater();

	autoUpdater.on("update-available", (info) => {
		dialog.showMessageBox({
			type: "info",
			title: "Update available",
			message: `Version ${info.version} is available. Download now?`,
			buttons: ["Download", "Later"],
		}).then(({ response }) => {
			if (response === 0) {
				autoUpdater.downloadUpdate();
			}
		});
	});

	autoUpdater.on("update-not-available", () => { // TODO: Add as setting to settings window
		dialog.showMessageBox({
			type: "info",
			title: "No updates",
			message: "You're on the latest version.",
			buttons: ["OK"],
		});
	});

	autoUpdater.on("update-downloaded", () => {
		dialog.showMessageBox({
			type: "info",
			title: "Update ready",
			message: "Update downloaded. The app will restart to apply the update.",
			buttons: ["Restart now", "Later"],
		}).then(({ response }) => {
			if (response === 0) {
				autoUpdater.quitAndInstall();
			}
		});
	});

	autoUpdater.on("error", (err) => {
		dialog.showMessageBox({
			type: "error",
			title: "Update error",
			message: `Failed to check for updates: ${err.message}`,
			buttons: ["OK"],
		});
	});

	try {
		await autoUpdater.checkForUpdates();
	} catch (err) {
		console.error("Failed to check for updates: ", err);
	}
}

function alt1Pressed() {
	let rsinst = getRsInstanceFromWnd(getActiveWindow());
	try {
		if (!rsinst) {
			throw new Error("Alt+1 pressed but no active rs client found");
		}
		rsinst.alt1Pressed();
	} catch (e) {
		console.log("alt+1 hotkey read failed: " + e);
	}
}

function getAutoUpdater(): AppUpdater {
	// Using destructuring to access autoUpdater due to the CommonJS module of 'electron-updater'.
	// It is a workaround for ESM compatibility issues, see https://github.com/electron-userland/electron-builder/issues/7976.
	const { autoUpdater } = require('electron-updater');
	autoUpdater.allowDowngrade = true;
	autoUpdater.autoDownload = false;
	return autoUpdater;
}

export function openApp(app: Bookmark, inst?: RsInstance) {
	if (!inst) {
		detectInstances();
		inst = rsInstances[0];
	}
	if (!inst) { console.error("no rs instance found"); }
	else { new ManagedWindow(app, inst); }
}

export class ManagedWindow {
	appConfig: Bookmark;
	window: BrowserWindow;
	nativeWindow: OSWindow;
	windowPin: OSWindowPin;
	rsClient: RsInstance;
	appFrameId = -1;
	activeTooltip = "";

	constructor(app: Bookmark, rsclient: RsInstance) {
        let posrect = app.lastRect;
        
        const clientBounds = rsclient.window.getBounds();
        
        const isOutOfBounds = !posrect ||
            posrect.left < -clientBounds.width ||
            posrect.left > clientBounds.width * 2 ||
            posrect.top < -clientBounds.height ||
            posrect.top > clientBounds.height * 2;
        
		if (!posrect || isOutOfBounds) {
			posrect = {
				left: 20, top: 20, width: app.defaultWidth, height: app.defaultHeight,
				bot: 0, right: 0,
				pinning: ["top", "left"]
			};
			app.lastRect = posrect;
			settings.appconfig.emit("changed");
		}

		this.window = new BrowserWindow({
			webPreferences: {
				nodeIntegration: true,
				webviewTag: true,
				contextIsolation: false,
				nodeIntegrationInSubFrames: false,
				nodeIntegrationInWorker: false
			},
			frame: false,
			enableLargerThanScreen: true,
			width: posrect.width,
			height: posrect.height,
			transparent: true,
			hasShadow: false,
			fullscreenable: false,
			resizable: false,//prevent electron from adding resize handlers that cover the dom around the border
			skipTaskbar: true,
			minimizable: false,
			maximizable: false,
			show: false,
		});
		remoteMain.enable(this.window.webContents);

		// this.window.webContents.openDevTools({ mode: "detach" });
		this.window.setVisibleOnAllWorkspaces(true, {visibleOnFullScreen: true});

		this.window.setVisibleOnAllWorkspaces(true, {visibleOnFullScreen: true, skipTransformProcessType: true});
		this.nativeWindow = new OSWindow(this.window.getNativeWindowHandle());
		this.rsClient = rsclient;
		this.appConfig = app;

		this.windowPin = new OSWindowPin(this.window, this.rsClient.window, "auto");
		this.windowPin.once("close", () => {
			this.window.close();
			app.wasOpen = true;
			settings.appconfig.emit("changed");
		});
		this.windowPin.setPinRect(posrect);

		this.window.loadFile(path.resolve(__dirname, "appframe/index.html"));
		this.window.once("close", () => {
			if (this.appFrameId !== -1) {
				this.rsClient.closeOverlayFrame(this.window.webContents.id);
			}
			managedWindows.splice(managedWindows.indexOf(this), 1);
			this.rsClient.overlayWindow?.browser.webContents.send("clearoverlay", this.appFrameId);
			this.windowPin.unpin();
			fixTooltip();
		});

		// NOTE: it's very very VERY important that the window must be created with `show: false` and that window.show()
		// must be called AFTER creating the OSWindowPin. This allows us to manipulate the window before the WM mangles it.
		this.window.once('ready-to-show', () => {
			this.window.show();
			this.windowPin.synchPosition(); // fixes electron not showing up sometimes
		});
		managedWindows.push(this);
	}
}

function updateTray() {
	if (!tray)
		throw new Error("No tray!");
	tray.on("click", e => tray!.popUpContextMenu());
	tray.setToolTip("Alt1 Lite");
	let menu: MenuItemConstructorOptions[] = [];
	for (let app of settings.bookmarks) {
		menu.push({
			label: app.appName,
			icon: app.iconCached ? nativeImage.createFromDataURL(app.iconCached).resize({ height: 20, width: 20 }) : undefined,
			click: openApp.bind(null, app, undefined),
		});
	}
	if (process.env.NODE_ENV === "development") {
		menu.push({ type: "separator" });
		menu.push({
			label: "Restart", click: e => {
				//relaunch uses the dir at time of call, there is no better way to give it the original dir
				process.chdir(originalCwd);
				app.relaunch();
				process.chdir(__dirname);
				app.quit();
			}
		});
		menu.push({ label: "Repin RS", click: e => { rsInstances.forEach(e => e.close()); detectInstances(); } });
		menu.push({ label: "Reload native addon", click: e => { reloadAddon(); } });
		menu.push(
			{
				label: "Hook dev tools: " + alwaysOpenDevtools,
				type: "checkbox",
				checked: alwaysOpenDevtools,
				icon: undefined,
				click: (e) => {
					alwaysOpenDevtools = e.checked;
					updateTray();
				}
			});
	}
	menu.push({ label: "Check for update", click: checkForUpdate });
	menu.push({ type: "separator" });
	menu.push({ label: "Settings", click: showSettings });
	menu.push({ label: "Exit", click: e => app.quit() });
	let menuinst = Menu.buildFromTemplate(menu);
	tray?.setContextMenu(menuinst);
}

function drawTray() {
	if (!tray) {
		if (process.platform === "darwin") {
			tray = new Tray(alt1icon.resize({ width: 16, height: 16 }));
		} else {
			tray = new Tray(alt1icon);
		}
		tray.on("click", e => tray!.popUpContextMenu());
	}
	tray.setToolTip("Alt1 Lite");
	updateTray();
}

let settingsWnd: BrowserWindow | null = null;
export function showSettings() {
	if (settingsWnd) {
		settingsWnd.focusOnWebView();
		return;
	}
	settingsWnd = new BrowserWindow({
		webPreferences: { nodeIntegration: true, webviewTag: true, contextIsolation: false },
	});
	settingsWnd.loadFile(path.resolve(__dirname, "settings/index.html"));
	settingsWnd.once("close", () => {
		admins.delete(settingsWnd!.webContents.id);
		settingsWnd = null;
	});
	remoteMain.enable(settingsWnd.webContents);
	admins.add(settingsWnd.webContents.id);
}

//TODO add permission
export function* selectAppContexts(rsinstance: RsInstance | null, permission: AppPermission | "") {
	for (let wnd of managedWindows) {
		if (rsinstance && rsinstance != wnd.rsClient) { continue; }
		//TODO move this to method on appconfig instead
		if (permission && !wnd.appConfig.permissions.includes(permission)) { continue; }
		if (wnd.appFrameId == -1) { continue; }
		let webcontent = electron.webContents.fromId(wnd.appFrameId);
		if (!webcontent) {
			console.log("webcontent empty, this should not be possible");
			continue;
		}
		yield webcontent;
	}
}

export function* selectAdminContexts() {
	for (let admin of admins) {
		let webcontent = electron.webContents.fromId(admin);
		if (webcontent) {
			yield webcontent;
		}
	}
}

class TooltipWindow {
	wnd: BrowserWindow;
	interval = 0;
	text: string;
	loaded = false;
	constructor() {
		let wnd = new BrowserWindow({
			webPreferences: { nodeIntegration: true, contextIsolation: false },
			frame: false,
			transparent: true,
			show: false,
			skipTaskbar: true,
			alwaysOnTop: true,
			minWidth: 10, minHeight: 10,
			width: 10, height: 10,
			focusable: false
		});
		wnd.loadFile(path.resolve(__dirname, "tooltip/index.html"));
		wnd.once("ready-to-show", () => {
			wnd.show();
		});
		wnd.webContents.once("dom-ready", () => {
			this.loaded = true;
			this.setTooltip(this.text);
		});
		wnd.on("closed", () => {
			if (this.interval) { clearInterval(this.interval) }
			tooltipWindow = null;
		});
		wnd.setIgnoreMouseEvents(true);
		this.wnd = wnd;
		tooltipWindow = this;
		this.interval = setInterval(this.fixPosition, 20) as any;
	}
	@boundMethod
	fixPosition() {
		let pos = electron.screen.getCursorScreenPoint()
		this.wnd.setPosition(pos.x + 20, pos.y + 20, true);//TODO check if animate is appropriate in mac (and maybe lower poll rate)
	}
	setTooltip(text: string) {
		this.text = text;
		if (this.loaded) {
			this.wnd.webContents.send("settooltip", this.text);
		}
	}
	close() {
		this.wnd.close();
	}
}

export function fixTooltip() {
	let text = "";
	for (let wnd of managedWindows) {
		if (wnd.activeTooltip) {
			if (text) { text += "\n"; }
			text += wnd.activeTooltip;
		}
	}

	if (text) {
		if (!tooltipWindow) {
			tooltipWindow = new TooltipWindow();
		}
		tooltipWindow.setTooltip(text);
	}
	if (!text && tooltipWindow) {
		tooltipWindow.close();
	}
}

